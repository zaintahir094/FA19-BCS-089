package com.example.e_commerce_clothes_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
