class Question {
  String questionText;
  List<String> data;
  int index;

  Question(String q, List<String> data_,int a) {
    questionText = q;
    data=data_;
    index = a;
  }
}
