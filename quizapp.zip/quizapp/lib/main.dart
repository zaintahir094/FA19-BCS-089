import 'dart:async';
import 'package:flutter/material.dart';
import 'package:quizapp/retry.dart';
import 'quiz_brain.dart';
import 'dart:ui';
import 'package:flutter/src/material/flat_button.dart';

void main() {
  runApp(SplashScreen());
}

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      title: 'Splash Screen',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: MyHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  void initState() {
    super.initState();
    Timer(
        Duration(seconds: 6),
        () => Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => QuizApp())));
  }
  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.white38,
        child: Column(
          children: <Widget>[
            Image(image: AssetImage('asset/quiz.jpg'), height: 400, width: 500,),
            Text("Let's start the quiz", style: TextStyle(fontSize: 40)),
            SizedBox(
              height: 30,
            ),
            CircularProgressIndicator()
          ],
        ));
  }
}

class QuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(

        backgroundColor: Colors.grey.shade900,
        body: SafeArea(child: QuizPage()

            ),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

     class _QuizPageState extends State<QuizPage> {


        QuizBrain quizBrain = QuizBrain();
          String timer = '60';
          List<Widget> scoreKeeper = [];
          int correct = 0;
        int wrong = 0;

         List<int> incorrect_answers = [];
      List<int> incorrect_answers2 = [];
    List<int> incorrect_selected_answers = [];
      List<int> correct_answers = [];
        List<int> selected_answers = [];
                          int count = 0;
           List<Widget> _getList(BuildContext context)
           {List<String> options = quizBrain.getoptions();

          List<Widget> temp = [];
          int _value = -1;
          for (var q = 1; q <= options.length; q++) {
          temp.add(ListTile(
              title: Text(
                options[q - 1],
                style: TextStyle(fontSize: 22, color: Colors.white),
              ),
              leading: Transform.scale(
                scale: 2.0,
                child: Radio(
                  hoverColor: Colors.indigo,
                  value: q,
                  groupValue: _value,
                  onChanged: (int value){
                    checkAnswer(q, context);
                    setState(() {
                      _value = value;
                      selected_answers.add(value);
                      // print()
                      count += 1;
                    });
                  },
                      ),
              ))


      );
    }
    return temp;
  }

  buttonFunction(id) async {
    var d = await Navigator.push(
        context,
        MaterialPageRoute(

            builder: (context) =>
                QuizApp2(id, quizBrain, selected_answers[id])));
    // print(d);
    if (d[0]) {
      setState(() {
        scoreKeeper[d[1]] = Icon(
          Icons.check,
          color: Colors.green,
        );
      });
      correct += 1;
      wrong -= 1;
      print(incorrect_answers);
      correct_answers.add(selected_answers[id]);
      int index = incorrect_answers.indexWhere(
          (i) => i.toString().contains(incorrect_answers2[id].toString()));
      if (index > -1) {
        incorrect_answers.removeAt(index);
      }

      // wrong_answers[]
    }
  }

  void checkAnswer(int userPickedAnswer, BuildContext context) {
    int correctAnswer = quizBrain.getCorrectAnswer();
    setState(() {
      if (quizBrain.isFinished() == true) {




        if (userPickedAnswer == correctAnswer) {
          correct_answers.add(quizBrain.get_number());
          correct += 1;
          scoreKeeper.add(Icon(
            Icons.check,
            color: Colors.green,
          ));



        } else {
          incorrect_answers.add(quizBrain.get_number());
          incorrect_selected_answers.add(userPickedAnswer);
          wrong += 1;
          scoreKeeper.add(IconButton(
            icon: Icon(
              Icons.close,
              color: Colors.red,
            ),
            onPressed: () {

            },
          ));
        }



        timer = 'complete';
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => SecondRoute(quizBrain, correct, wrong,
                    correct_answers, wrong_answers, timer)));
      }



      else {
        incorrect_answers2.add(quizBrain.get_number());
        if (userPickedAnswer == correctAnswer) {
          correct_answers.add(quizBrain.get_number());
          correct += 1;
          scoreKeeper.add(Icon(
            Icons.check,
            color: Colors.green,
          ));





        } else {
          wrong_answers.add(quizBrain.get_number());

          scoreKeeper.add(
              // score_wrong(count)
              new FAB(
            id: count,
            onPressed: buttonFunction,
          ));
          wrong += 1;
        }
        quizBrain.nextQuestion();
      }
    });
  }


  @override
  Widget build(BuildContext context) {
    // quizBrain.shuffle();
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        TweenAnimationBuilder<Duration>(
            duration: Duration(minutes: 1),
            tween: Tween(begin: Duration(minutes: 1), end: Duration.zero),
            onEnd: () {

              timer = 'time';
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => SecondRoute(quizBrain, correct,
                          wrong, correct_answers, incorrect_answers, timer)));
            },

            builder: (BuildContext context, Duration value, Widget child) {
              var minutes = value.inMinutes;
                      var seconds = value.inSeconds % 60;
                       return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 5),
                        child:Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                      Icon(
                        Icons.alarm,
                        color: Colors.red,
                        size: 50,
                      ),
                      Text('$minutes:$seconds',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 50))
                    ],
                  ));
            }),
        Container(
          height: 50,
          width: 150,
          child: FlatButton(
            color: Color(0xFF00E676),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),

            textColor: Colors.black,
            child: new Text(
              "Stop Quiz",
              style: TextStyle(fontSize: 25),


            ),
            onPressed: () {

              timer = 'stop';
              Navigator.push(
                  context,
                  MaterialPageRoute(

                      builder: (context) => SecondRoute(quizBrain, correct,
                          wrong, correct_answers, incorrect_answers, timer)));
            },
          ),
        ),



        Expanded(
          flex: 1,
          child: Padding(
            padding: EdgeInsets.all(10.0),
            child: Center(
              child: Text(
                quizBrain.getQuestionText(),
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 25.0,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
        Column(
          children: _getList(context),
        ),

        Row(
          children: scoreKeeper,
        ),
      ],
    );
  }
}

class SecondRoute extends StatelessWidget {
  QuizBrain quizBrain;
  int correct;
  int wrong;
  String timer;
  List<int> incorrect_answers;
  List<int> correct_answers;


  SecondRoute(this.quizBrain, this.correct, this.wrong, this.correct_answers,
      this.incorrect_answers, this.timer,
      {Key key})
      : super(key: key);
  Widget check_timer(bool check) {
    if (timer == 'time' && check == true) {
      return Container(
        child: Text(
          'Time Up',
          style: TextStyle(
              fontSize: 40, color: Color(0xFF00E676), fontWeight: FontWeight.bold),
        ),
      );
    } else if (timer == 'stop' && check == true) {
      return Container(
        child: Text(
          'Quiz Stopped',
          style: TextStyle(
              fontSize: 30, color: Color(0xFF00E676), fontWeight: FontWeight.bold),
        ),
      );
    } else if (timer == 'complete' && check == true) {
      return Container(
        child: Text(
          'Quiz Completed',
          style: TextStyle(
              fontSize: 30, color: Colors.white, fontWeight: FontWeight.bold),
        ),
      );
    } else if (!check && timer != 'complete') {
      return Container(
          child: Column(
        children: <Widget>[
          Text(
            '${10 - (correct + wrong)}',
            style: TextStyle(fontSize: 30, color: Colors.white),
          ),
          Text(
            'Unattempted Question',
            style: TextStyle(
                fontSize: 30, color: Colors.white, fontWeight: FontWeight.bold),
          )
        ],
      ));
    } else {
      return SizedBox(
        height: 0,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade900,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.black12,
        title: Text("FA19-BCS-089"),

        leading: new IconButton(

            icon: new Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => QuizApp()));
            }),
      ),
      body: Center(
          child: SingleChildScrollView(
              child: Column(
        children: <Widget>[
          Container(
            color: Colors.black,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                check_timer(true),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Container(
                      child: Text(
                        '${correct}',
                        style: TextStyle(fontSize: 30, color: Colors.white),
                      ),
                    ),
                    Container(
                      child: Text('${wrong}',
                          style: TextStyle(fontSize: 30, color: Colors.white)),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Container(
                      child: Text("True  Answers",
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                              fontWeight: FontWeight.bold)),
                    ),
                    Container(
                      child: Text("Wrong Answers",
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                              fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
                check_timer(false),

              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          // SingleChildScrollView(
          Column(
            children: quizBrain.getallquestion(incorrect_answers, 0),
          ),
          // ),
          // SingleChildScrollView(
          Column(
            children: quizBrain.getallquestion(correct_answers, 1),
          )
          // )
        ],
      ))),
    );
  }
}

class FAB extends StatelessWidget {
  final int id;
  final Function(int) onPressed;
  // final String buttonText;

  const FAB({this.id, this.onPressed});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 30,
      child: IconButton(
        icon: Icon(
          Icons.close,
          color: Colors.red,
        ),
        onPressed: () {
          onPressed(this.id);
        },
      ),
    );

  }
}
