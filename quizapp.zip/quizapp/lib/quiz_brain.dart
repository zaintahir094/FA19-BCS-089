import 'package:flutter/cupertino.dart';
import 'package:quizapp/question.dart';
import 'package:flutter/material.dart';
import 'dart:math';

class QuizBrain {

  int _questionNumber = 0;

  List<Question> _questionBank = [

    Question('Who developed Flutter?',
        ["Google", "Microsoft", "Facebook", "Mozilla"], 1),

    Question('Which language used by Flutter',
        ["Swift", "C++", "Dart", "Angular"], 3),

    Question('Without the main() function, we cannot write any program on Flutter.',
        ["True", "False"], 1),

    Question('The loudest sound produced by any animal is 188 decibels. That animal is the African Elephant.',
        ["True", "False"], 2 ),

    Question(' What is Flutter?', ["Flutter is an open-source DBMS", "Flutter is an open-source UI toolkit",
      "Flutter is an open-source backend toolkit", "All of the above"], 2),


    Question('The first alpha version of Flutter was released in?',
        ["May 2016", "May 2017", "May 2018", "May 2019"], 1),

    Question('What is the correct way to define Text in flutter?',
        ["Text('Some value')", "text()", "TEXT(hello)", "Text(some value)"], 1),

    Question(
        'A notable feature of the Dart platform is its support for "hot reload"',
        ["True", "False"],
        1),
    Question( 'Flutter is developed by ________.',
        ["Microsoft", "Google", "Facebook", "IBM"], 2),

    Question('SDK stands for _________.',
        [" Software Development Knowledge", "Software Data Kit", "Software Development Kit", "Software Database Kit"], 3)

       ]..shuffle();



    void nextQuestion() {
     if (_questionNumber < _questionBank.length - 1) {
      _questionNumber++;
    }
  }


  String getQuestionText() {
    return _questionBank[_questionNumber].questionText;
  }

  String getQuestionText_index(int index) {
    return _questionBank[index].questionText;
  }

  int get_number() {
    return _questionNumber;
  }

  int getCorrectAnswer() {
    return _questionBank[_questionNumber].index;
  }

  int getCorrectAnswer_index(int index) {
    return _questionBank[index].index;
  }

  List<String> getoptions() {
    return _questionBank[_questionNumber].data;
  }

  List<String> getoptions_index(int index) {
    return _questionBank[index].data;
  }

  bool isFinished() {
    if (_questionNumber >= _questionBank.length - 1) {
      return true;
    } else {
      return false;
    }
  }

  List<Widget> getallquestion(List<int> wrongans, int type)
  {
    List<Widget> temp = [];

    for (int i = 0; i < wrongans.length; i++) {
      int t = wrongans[i];
      if (t != -10) {
        if (i == 0 && type == 0) {
          temp.add(Text(

            "Wrong Answers",

            style: TextStyle(

                fontSize: 40, color: Color(0xFF00E676), fontWeight: FontWeight.bold),
          ));


          SizedBox(
            height: 50,
            child: Divider(
              color: Colors.black,
              height: 4,
            ),
          );
        } else if (i == 0 && type == 1) {
          temp.add(Text(
            "Correct Answers",
            style: TextStyle(
                fontSize: 40, color: Color(0xFF00E676), fontWeight: FontWeight.bold),
          ));
        }
        temp.add(Container(
                color: Colors.yellow,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Text(
                      _questionBank[t].questionText,
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[

                        Text(
                                "Answer: ",
                                 style: TextStyle(
                                 color: Colors.red,
                                 fontSize: 20, fontWeight: FontWeight.bold),
                                 ),


                        Text(
                               _questionBank[t].data[_questionBank[t].index - 1],
                                style: TextStyle(fontSize: 20),
                                ),
                                ],
                                ),


                    SizedBox(
                      height: 50,
                      child: Divider(
                        color: Colors.black,
                        height: 2,
                         ),
                          )
                           ],
                         ))


                        );
                        }
                        }
                         return temp;
                          }

  void reset() {
    _questionNumber = 0;
  }
}
